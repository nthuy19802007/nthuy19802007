﻿namespace CodeIndex.VisualStudioExtension.Models
{
    public class HintWord
    {
        public string Word { get; set; }
    }
}
