﻿namespace CodeIndex.IndexBuilder
{
    public static class CodeContentProcessing
    {
        public const string HighLightPrefix = "0ffc7664bb0";
        public const string HighLightSuffix = "b17f5526cc3";
    }
}
