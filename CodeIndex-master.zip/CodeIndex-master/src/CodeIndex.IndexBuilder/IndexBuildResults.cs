﻿namespace CodeIndex.IndexBuilder
{
    public enum IndexBuildResults
    {
        Successful,
        FailedWithIOException,
        FailedWithoutError,
        FailedWithError
    }
}
