﻿namespace CodeIndex.Common
{
    public class CodeWord
    {
        public string Word { get; set; }
        public string WordLower { get; set; }
    }
}
