﻿namespace CodeIndex.Common
{
    public class Status
    {
        public bool Success { get; set; }
        public string StatusDesc { get; set; }
    }
}